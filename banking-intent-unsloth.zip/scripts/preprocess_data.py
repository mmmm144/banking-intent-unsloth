import pandas as pd
from datasets import load_dataset
from sklearn.model_selection import train_test_split
import os

def preprocess():
    # 1. Tải dataset (mteb đã sửa lỗi script thành công) 
    dataset = load_dataset("mteb/banking77")
    df = pd.DataFrame(dataset['train'])

    # 2. Định nghĩa danh sách nhãn thủ công (vì bản mteb không chứa .names)
    # Đây là danh sách intent chuẩn của BANKING77 [cite: 28, 30]
    # Nếu chỉ cần demo, ta có thể bỏ qua bước ánh xạ tên và dùng ID số trực tiếp.
    # Tuy nhiên, để đúng yêu cầu "label mapping" của thầy Long :
    
    # Cách đơn giản nhất để lấy text cho việc fine-tune:
    # Nếu dataset không có sẵn names, ta sẽ dùng trực tiếp cột label số 
    # Hoặc nếu muốn train bằng text intent (khuyên dùng cho LLM):
    df['intent_name'] = df['label'].astype(str) # Dùng ID nhãn làm tên tạm thời

    # 3. Lấy mẫu (Sampling) 30 dòng mỗi nhãn để nhẹ máy [cite: 29]
    df_sampled = df.groupby('label').apply(
        lambda x: x.sample(n=min(len(x), 100), random_state=42)
    ).reset_index(drop=True)
    # 4. Chia dữ liệu [cite: 32]
    train_df, test_df = train_test_split(df_sampled, test_size=0.2, random_state=42)
    
    # 5. Lưu file vào đúng cấu trúc thư mục yêu cầu 
    os.makedirs("sample_data", exist_ok=True)
    train_df.to_csv("sample_data/train.csv", index=False)
    test_df.to_csv("sample_data/test.csv", index=False)
    
    print("--- HOÀN THÀNH ---")
    print(f"Tổng số dòng train: {len(train_df)}")
    print(f"Tổng số dòng test: {len(test_df)}")
    print("Các file đã được tạo trong thư mục sample_data/")

if __name__ == "__main__":
    preprocess()