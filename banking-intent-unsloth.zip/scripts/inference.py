import yaml
import torch
from unsloth import FastLanguageModel

class IntentClassification:
    def __init__(self, config_path):
        with open(config_path, "r") as f:
            cfg = yaml.safe_load(f)
        
        # Load model từ folder outputs bạn đã tải về
        self.model, self.tokenizer = FastLanguageModel.from_pretrained(
            model_name = cfg['model_checkpoint'],
            max_seq_length = 64,
            load_in_4bit = True,
        )
        FastLanguageModel.for_inference(self.model)

    def __call__(self, message):
        inputs = self.tokenizer([message], return_tensors = "pt").to("cuda" if torch.cuda.is_available() else "cpu")
        outputs = self.model.generate(**inputs, max_new_tokens = 20)
        # Lấy phần văn bản mới được tạo ra (nhãn)
        full_text = self.tokenizer.batch_decode(outputs, skip_special_tokens=True)[0]
        return full_text.replace(message, "").strip()

if __name__ == "__main__":
    # Test thử một câu
    classifier = IntentClassification("configs/inference.yaml")
    msg = "I lost my credit card, what should I do?"
    print(f"Input: {msg}")
    print(f"Predicted Intent: {classifier(msg)}")