import yaml
import torch
from unsloth import FastLanguageModel
from datasets import load_dataset
from transformers import TrainingArguments, Trainer, DataCollatorForLanguageModeling

def train():
    # 1. Load config
    with open("configs/train.yaml", "r") as f:
        config = yaml.safe_load(f)

    # 2. Load Model & Tokenizer
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name = config['model_name'],
        max_seq_length = config['max_seq_length'],
        load_in_4bit = True,
    )
    model = FastLanguageModel.get_peft_model(
        model, r = 16, target_modules = ["q_proj", "k_proj", "v_proj", "o_proj"],
        lora_alpha = 16, lora_dropout = 0,
    )

    # 3. Load và Tokenize dữ liệu
    dataset = load_dataset("csv", data_files=config['dataset_path'], split="train")
    def tokenize_fn(batch):
        return tokenizer(batch["text"], truncation=True, max_length=config['max_seq_length'])
    
    tokenized_ds = dataset.map(tokenize_fn, batched=True, remove_columns=dataset.column_names)

    # 4. Huấn luyện (Dùng Trainer để tránh lỗi cache Unsloth)
    trainer = Trainer(
        model = model,
        train_dataset = tokenized_ds,
        args = TrainingArguments(
            per_device_train_batch_size = 4,
            gradient_accumulation_steps = 4,
            max_steps = 60,
            learning_rate = 2e-4,
            fp16 = True,
            logging_steps = 1,
            output_dir = "outputs",
            optim = "adamw_8bit",
            report_to = "none",
        ),
        data_collator = DataCollatorForLanguageModeling(tokenizer, mlm=False),
    )

    print("Bắt đầu train...")
    trainer.train()

    # 5. Lưu model đã merge 16-bit để inference nhẹ hơn
    model.save_pretrained_merged(config['output_dir'], tokenizer, save_method = "merged_16bit")
    print(f"Đã lưu model tại {config['output_dir']}")

if __name__ == "__main__":
    train()